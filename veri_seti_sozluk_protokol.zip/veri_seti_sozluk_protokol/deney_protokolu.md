# Deney Protokolü

**Proje:** Üretim İşletmeleri İçin Yapay Zekâ Destekli Otomatik Maliyetlendirme ve Satış Teklifi Oluşturma Sistemi (SmartCost ERP & B2B Portalı)

Bu belge, projede yürütülecek deneylerin nasıl yapılacağını adım adım tanımlar. Deneyler başlamadan önce yöntem sabitlenir; sonuçlar hedefe ulaşılsa da ulaşılmasa da olduğu gibi raporlanır.

## 1. Amaç ve hipotezler

| Hipotez | İfade |
|---|---|
| **H1 – NLP doğruluğu** | Önerilen ayrıştırıcı, ayrık test kümesinde kalem düzeyinde F1 ≥ %90 (hedef ≥ %95) elde eder ve temel yöntemlerden (B0, B1) istatistiksel olarak anlamlı biçimde daha yüksek F1 verir. |
| **H2 – Süre** | Otomatik teklif hazırlama, manuel hazırlamaya göre uçtan uca süreyi ortancada en az %80 (hedef ≥ %95) azaltır; sistem işlem süresi ağ dâhil ortancada 3 saniyenin altındadır. |
| **H3 – Hata ve tutarlılık** | Deterministik maliyet hesabı ve iki aşamalı onay, manuel hesaba göre daha düşük hatalı teklif oranı sağlar; ön izleme stoğu değiştirmez, onay sonrası düşüm sipariş adedine eşittir, aynı sepet her tekrarda aynı tutarı üretir. |

Kullanılabilirlik (SUS ≥ 68, görev tamamlama ≥ %90) betimsel bir kabul ölçütüdür; hipotez testi yapılmaz.

## 2. Genel ilkeler
- Karşılaştırmalar aynı veri ve aynı koşullarda yapılır.
- Kural ayarı ve eşik belirleme **yalnızca doğrulama kümesinde** yapılır; test kümesi nihai ölçümde **tek kez** kullanılır.
- Tüm deneyler sabit rastgele tohumla (2026) ve betiklerle yürütülür; sonuçlar JSON olarak kaydedilir.
- Hedefe ulaşılamazsa kabul alt sınırı esas alınır; alt sınıra da ulaşılamazsa sonuç hata analiziyle birlikte olduğu gibi raporlanır.

## 3. Veri
- **Ürün kataloğu:** `veri/urun_katalogu.csv` (1.434 ürün–ebat satırı). Fiyatlar birim malzeme maliyeti için vekil değer olarak alınır.
- **Sipariş cümleleri:** `veri/siparis_cumleleri/` (1.000 etiketli sentetik cümle; proje sürecinde 1.500'e çıkarılması hedeflenir). Her cümle 1–4 ürün–ebat–adet kalemi içerir ve (ürün kimliği, adet) çiftleri olarak etiketlidir.
- **Bölme:** Model bazında %60 eğitim / %20 doğrulama / %20 test. Bir model iki bölümde yer almaz (ortak model = 0). Test cümleleri geliştirmede kullanılmayan cümle kalıpları içerir; yazım hatalı cümleler (%20) yalnızca testte, ayrı alt küme olarak tutulur.
- **Gönüllü cümleler:** Ekip dışı gönüllülerden katalog gösterilerek serbestçe yazdırılan en az 100 sipariş cümlesi toplanır, iki kişice elle etiketlenir ve sentetik test kümesinden ayrı raporlanır. Kişisel veri maskelenir.
- **Etiket kontrolü:** Cümlelerin rastgele %10'u iki kişice bağımsız kontrol edilir; etiket uyumu ≥ %98 olmalıdır.

## 4. Deneyler

### D1 – NLP ayrıştırıcı doğruluğu (H1)
**Karşılaştırılan yöntemler:**
- **B0:** Anahtar kelime arama (normalizasyon ve bulanık eşleştirme yok; tam alt dizge, ilk sayı = adet).
- **B1:** Karakter n-gram (3–5) TF-IDF + kosinüs benzerliği.
- **B2 (isteğe bağlı):** Az örnekli (few-shot) büyük dil modeli, 100 cümlelik alt kümede.
- **Önerilen:** Türkçe normalizasyon + Regex (ebat/adet) + bağlaç ayrıştırma + Levenshtein tabanlı bulanık eşleştirme (eşik ≥ 0,85).

**Adımlar:**
1. Eşik ve kurallar doğrulama kümesinde ayarlanır.
2. Yöntemler değiştirilmeden test kümesinde tek kez çalıştırılır (temiz, yazım hatalı ve gönüllü alt kümeler ayrı).
3. Kalem düzeyinde kesinlik, duyarlılık, F1 ve cümle düzeyinde tam eşleşme hesaplanır.
4. Her bileşen tek tek çıkarılarak (ablasyon) katkısı ölçülür; hata türleri (yanlış ürün, kaçan kalem, yanlış adet, yanlış ebat) analiz edilir.

### D2 – Manuel ve otomatik teklif süresi (H2)
1. 1–4 kalemli en az 30 sipariş metni seçilir.
2. Her metin hem manuel (fiyat listesi, stok tablosu, hesap makinesi/tablo) hem otomatik (portal) yöntemle teklife dönüştürülür.
3. En az üç gönüllü uygulayıcı katılır (sistemi geliştirmemiş kişiler); yöntem sırası dengelenir (yarısı önce manuel, yarısı önce otomatik); aynı metin ikinci kez farklı uygulayıcıya verilir.
4. Süre, metnin verilmesinden teklif belgesinin hazır olmasına kadar kronometreyle ölçülür.
5. **Ön pilot:** Otomatik ölçümlerden önce en az 5 sipariş manuel hazırlanarak manuel süre varsayımı (15–30 dk) doğrulanır. Hedef eşik yalnızca bu sonuca göre **en çok bir kez** güncellenebilir; alt sınır (%80) sabit kalır.

### D3 – Hata, stok ve tutarlılık (H3)
1. En az 100 senaryoda sistemin hesapladığı malzeme, operasyon, kâr ve toplam tutar, bağımsız bir hesap tablosu/betikle karşılaştırılır; fark 0,00 ₺'den büyükse teklif "hatalı" sayılır.
2. Aynı sepet 100 kez işlenir; farklı sonuç sayısı sayılır.
3. Ön izleme öncesi/sonrası ve onay öncesi/sonrası stok değerleri karşılaştırılır (ön izleme: değişim 0; onay: düşüm = adet).
4. En az 50 eşzamanlı onay denemesiyle stok aşımı olup olmadığı sınanır.
5. D2'deki manuel tekliflerin hatalı teklif oranı aynı referans hesapla belirlenir.

### D4 – Sistem işlem süresi (H2)
Ayrıştırma, fiyatlama, onay ve PDF adımları `time.perf_counter` ile milisaniye cinsinden günlüğe yazılır. İlk istek (soğuk başlangıç) ayrı raporlanır; sonraki en az 100 istek için ortanca ve %95. yüzdelik hesaplanır. Ölçüm yerel ve uzak sunucuda (ağ gecikmesi dâhil) yapılır.

### D5 – Kullanılabilirlik
En az 10 kullanıcı üç görevi (sipariş girme, ön izleme ve onay, PDF indirme) yerine getirir. Görev tamamlama oranı ve süresi kaydedilir; ardından System Usability Scale (SUS) uygulanır.

## 5. Değişkenler

| Tür | Değişken |
|---|---|
| Bağımsız | Ayrıştırma yöntemi (B0, B1, B2, önerilen); teklif hazırlama yöntemi (manuel/otomatik); girdi gürültü düzeyi (temiz/yazım hatalı); kalem sayısı (1–4); metin kaynağı (sentetik/gönüllü); ortam (yerel/uzak) |
| Bağımlı | Kalem düzeyi kesinlik, duyarlılık, F1; cümle düzeyi tam eşleşme; uçtan uca süre (sn); sistem işlem süresi (ms); hatalı teklif oranı; ₺ farkı; stok farkı; SUS; görev tamamlama |
| Kontrol | Fiyat listesi tarihi, maliyet katsayıları (%15 operasyon, %20 kâr), rastgele tohum, donanım, katılımcı yönergesi, sipariş metinleri |

## 6. Ölçütlerin tanımı
- **Doğru pozitif (TP):** (ürün kimliği, adet) çifti etiketle birebir eşleşir. **YP (FP):** tahmin edilen ama etikette olmayan çift. **YN (FN):** etikette olup bulunamayan çift.
- Kesinlik = TP/(TP+FP); Duyarlılık = TP/(TP+FN); F1 = 2·K·D/(K+D). Tüm test kalemleri üzerinde mikro ortalama.
- Doğruluk (cümle tam eşleşme) = tüm kalemleri doğru olan cümle oranı.
- İyileşme: ΔF1 = F1(önerilen) − F1(temel yöntem).

## 7. İstatistiksel analiz

| Karşılaştırma | Yöntem |
|---|---|
| F1 farkları (D1) | Eşleştirilmiş bootstrap (1.000 yineleme), %95 güven aralığı; B0/B1/B2 karşılaştırmalarında Bonferroni (α = 0,05/3) |
| Cümle düzeyi doğruluk, hatalı teklif oranı | McNemar testi |
| Manuel ve otomatik süre (D2) | Wilcoxon işaretli sıralar testi (α = 0,05); etki büyüklüğü r = Z/√N; ortanca ve %95. yüzdelik |
| Sistem süresi ve tutarlılık (D3, D4) | Sayım, oran, ortanca, yüzdelik (betimsel) |
| Kullanılabilirlik (D5) | SUS ortalaması, standart sapma, %95 güven aralığı; eşik ≥ 68 |

Örneklem büyüklükleri (≥ 30 sipariş, ≥ 10 kullanıcı) güç analizine değil kapasiteye dayanır; sonuçlar p değerleriyle birlikte etki büyüklüğü ve güven aralıklarıyla yorumlanır.

## 8. Başarı ölçütleri

| Hedef | Ölçüt | Hedef (alt sınır) | Deney |
|---|---|---|---|
| 1 | F1, test kümesi | ≥ %95 (≥ %90) | D1 |
| 2 | F1, yazım hatalı alt küme | ≥ %80 | D1 |
| 3 | ΔF1, B0 ve B1'e göre | Pozitif; bootstrap %95 GA sıfırı içermez | D1 |
| 4 | Sistem işlem süresi (ağ dâhil), ortanca | < 3 sn | D4 |
| 5 | Manuel yönteme göre süre azalması (ortanca, n ≥ 30) | ≥ %95 (≥ %80; p < 0,05) | D2 |
| 6 | Bağımsız hesapla fark | ≥ 100 senaryoda 0,00 ₺ | D3 |
| 7 | Stok bütünlüğü ve tutarlılık | Ön izlemede değişim 0; onayda düşüm = adet; 100 tekrarda tek sonuç; 50 eşzamanlı denemede stok aşımı 0 | D3 |
| 8 | SUS, görev tamamlama | ≥ 68; ≥ %90 | D5 |

## 9. Kayıt ve yeniden üretilebilirlik
Ölçüm betikleri, ham sonuçlar (JSON), kullanılan veri sürümü ve rastgele tohum depoda saklanır; herkes aynı sonuçları yeniden üretebilmelidir.

## 10. Sınırlılıklar
- Veriler büyük ölçüde sentetiktir ve tek bir kataloğa dayanır; sonuçlar kontrollü ortam bulgusudur, gerçek işletme verisiyle doğrulanmadan genellenemez. Gönüllü cümleler bu sınırlılığı kısmen azaltmak için ayrı raporlanır.
- Fiyatlar birim malzeme maliyeti için vekil değerdir; maliyet katsayıları (%15, %20) sabit varsayımdır.
- Eşzamanlılık testleri SQLite'ın tek yazıcı kısıtı altında yapılır.
