# Veri Sözlüğü

SmartCost ERP & B2B veri setindeki tüm dosya ve sütunların açıklaması. Tüm CSV dosyaları UTF-8 (BOM'lu) kaydedilmiştir; ondalık ayırıcı noktadır (`11886.14`).

## 1. `veri/urun_katalogu.csv` – ürün kataloğu (1.434 satır)

| Sütun | Tip | Açıklama |
|---|---|---|
| `urun_id` | int | Benzersiz ürün–ebat kimliği (sistem veritabanıyla aynı) |
| `kategori_kodu` | str | Sistem kodu: `YATAK`, `BAZA`, `BASLIK`, `SET`, `YASTIK` ... |
| `kategori` | str | Türkçe kategori adı |
| `model` | str | Model/seri adı; aynı modelin ebatları aynı değeri taşır |
| `ebat` | str | `160x200` (en×boy cm), `160` (başlık genişliği), `TEK KISILIK` / `CIFT KISILIK` / `BATTAL` ya da boş |
| `ebat_turu` | str | `en_x_boy`, `genislik`, `kisilik_sinifi`, `yok` |
| `en_cm`, `boy_cm` | int | Ebattan ayrıştırılmış ölçüler (yoksa boş) |
| `urun_adi` | str | Tam ürün adı |
| `liste_fiyati_tl` | float | Liste fiyatı, ₺ |
| `kampanyali_fiyat_tl` | float | Kampanyalı fiyat (yalnız 6 üründe) |
| `satis_fiyati_tl` | float | Geçerli fiyat = kampanyalı varsa o, yoksa liste fiyatı |
| `kdv_dahil` | str | Liste fiyatlarına KDV dâhildir (`evet`) |
| `baslangic_stok` | int | Sentetik başlangıç stoğu (her ürün için 50) |
| `kaynak_liste` | str | Satırın alındığı liste |
| `fiyat_tarihi` | date | Fiyat listesinin tarihi |

## 2. `veri/urun_ozellikleri.csv` – türetilmiş özellikler

| Sütun | Açıklama |
|---|---|
| `urun_id` | Katalogdaki ürün kimliği |
| `kategori`, `model`, `ebat`, `ebat_turu` | Katalogdan alınan alanlar |
| `en_cm`, `boy_cm` | Ölçüler (cm) |
| `alan_m2` | En × boy alanı (m²), ebat en×boy ise |
| `kisilik_sinifi` | Ebattan türetilen kişilik sınıfı (sayısal kod) |
| `kampanya` | Kampanyalı ürün mü (0/1) |
| `havuzlu` | Havuzlu (yaylı) ürün mü (0/1) |
| `kaynak_kod` | Kaynak liste kodu |
| `satis_fiyati` | Geçerli satış fiyatı (₺) |
| `log_fiyat` | Satış fiyatının 10 tabanlı logaritması |

## 3. `veri/set_bilesen_karsilastirma.csv` – set fiyatı ve bileşen toplamı

| Sütun | Açıklama |
|---|---|
| `model` | Set modeli |
| `ebat` | Ebat |
| `set` | Set fiyatı (₺) |
| `toplam` | Bileşenlerin (yatak + baza + başlık) fiyat toplamı (₺) |
| `oran` | `set / toplam` |

## 4. `veri/siparis_cumleleri/` – etiketli sipariş cümleleri (1.000 cümle)

Gerçek müşteri talebi kullanılmadan üretilmiş etiketli sentetik veridir.

### `train.csv`, `val.csv`, `test.csv`

| Sütun | Açıklama |
|---|---|
| `cumle_id` | Cümlenin benzersiz kimliği |
| `yazim_hatali` | Cümlede yazım hatası var mı (0/1); yalnızca test kümesinde 1 olabilir |
| `kalem_sayisi` | Cümledeki ürün kalemi sayısı (1–4) |
| `metin` | Serbest metin sipariş cümlesi |
| `etiket_json` | Doğru cevap: `[{"urun_id", "adet", "urun_adi"}, ...]` biçiminde JSON |

### `train.jsonl`, `val.jsonl`, `test.jsonl`
Cümle başına bir JSON nesnesi. Alanlar: `cumle_id`, `bolum`, `yazim_hatali` (true/false), `metin`, `kalemler` (liste; her öğe `urun_id`, `adet`, `urun_adi`).

### `etiketler_uzun.csv` – kalem başına bir satır

| Sütun | Açıklama |
|---|---|
| `cumle_id` | Kalemin ait olduğu cümle |
| `bolum` | `train`, `val` veya `test` |
| `sira` | Kalemin cümledeki sırası |
| `urun_id` | Katalogdaki ürün kimliği |
| `adet` | İstenen adet |
| `urun_adi` | Ürün adı |

### `bolum_modelleri.csv` – hangi model hangi bölümde

| Sütun | Açıklama |
|---|---|
| `bolum` | `train`, `val` veya `test` |
| `kategori_kodu` | Ürün kategorisi |
| `model` | Model adı (bir model yalnızca tek bölümde yer alır) |
